module Noticias::ResourceHelper
end
