class Noticias::HomeController < Noticias::ResourceController
  def index

  end
end
