class Noticias::ResourceController < Noticias::ApplicationController
 inherit_resources
 respond_to :html
end
