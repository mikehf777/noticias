class DashboardController < ApplicationController
  ###Layout principal del sistema
  def index
  	
  end
end
